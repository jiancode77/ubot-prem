const { TelegramClient } = require("telegram");
const { StringSession } = require("telegram/sessions");
const { NewMessage } = require("telegram/events");
const input = require("input");
const fs = require("fs");

// === API ID & API HASH ===
const apiId = 25683949; // ganti
const apiHash = "5a0f1b821252088fe36c523c01c82533"; // ganti

// Lokasi file session & blacklist
const SESSION_FILE = "session.json";
const BLACKLIST_FILE = "blacklist.json";

// === FOOTER ===
const withFooter = (text) => {
  return `${text}\n\n<blockquote>UNSERBOT BY | TZY | Rann</blockquote>`;
};

// Load blacklist
let blacklist = [];
if (fs.existsSync(BLACKLIST_FILE)) {
  try {
    blacklist = JSON.parse(fs.readFileSync(BLACKLIST_FILE));
  } catch (e) {
    console.log("❌ File blacklist corrupt, buat baru");
    blacklist = [];
  }
}
const saveBlacklist = () => {
  fs.writeFileSync(BLACKLIST_FILE, JSON.stringify(blacklist, null, 2));
};

// Baca session dari file
let savedSession = "";
if (fs.existsSync(SESSION_FILE)) {
  try {
    const data = JSON.parse(fs.readFileSync(SESSION_FILE));
    savedSession = data.session || "";
  } catch (e) {
    console.log("❌ Session corrupt, login ulang diperlukan");
  }
}
const stringSession = new StringSession(savedSession);

// === Variabel AFK ===
let isAfk = false;
let afkReason = "";

(async () => {
  console.log("=== Telegram UserBot Start ===");

  const client = new TelegramClient(stringSession, apiId, apiHash, {
    connectionRetries: 5,
  });

  if (!savedSession) {
    await client.start({
      phoneNumber: async () => {
        console.log("=== LOGIN TELEGRAM ===");
        console.log("📱 Silakan masukkan nomor telepon Anda (+62xxx):");
        return await input.text("> Nomor: ");
      },
      phoneCode: async () => {
        console.log("📩 Telegram sudah mengirimkan kode OTP ke akun Anda.");
        console.log("Silakan masukkan kode OTP (biasanya 5 digit):");
        return await input.text("> OTP: ");
      },
      password: async () => {
        console.log("🔑 Akun Anda menggunakan verifikasi dua langkah (2FA).");
        console.log("Masukkan sandi/password 2FA:");
        return await input.text("> Password 2FA: ");
      },
      onError: (err) => console.log("❌ Error:", err),
    });

    fs.writeFileSync(
      SESSION_FILE,
      JSON.stringify({ session: client.session.save() }, null, 2)
    );
    console.log("💾 Session baru disimpan ke", SESSION_FILE);
  } else {
    await client.connect();
    console.log("✅ Auto-login pakai session.json");
  }

  const me = await client.getMe();
  const myId = me.id.toString();

  // FIX startup message
  await client.sendMessage("me", {
    message: withFooter("UserBot aktif 🚀"),
    parseMode: "html",
  });

  // === EVENT HANDLER ===
  client.addEventHandler(
    async (event) => {
      const msg = event.message;
      if (!msg || !msg.message) return;
      const text = msg.message.trim();

      // ================= AFK FEATURE =================
      if (msg.senderId.toString() === myId) {
        if (text.startsWith(".afk")) {
          const reason = text.split(" ").slice(1).join(" ") || "Tidak ada keterangan";
          isAfk = true;
          afkReason = reason;
          await client.sendMessage(msg.chatId, {
            message: withFooter(`✅ Mode AFK diaktifkan!\nKeterangan: ${reason}`),
            parseMode: "html",
            replyTo: msg.id,
          });
          return;
        }

        if (text === ".unafk") {
          isAfk = false;
          afkReason = "";
          await client.sendMessage(msg.chatId, {
            message: withFooter("✅ Mode AFK dinonaktifkan!"),
            parseMode: "html",
            replyTo: msg.id,
          });
          return;
        }
      } else {
        if (isAfk) {
          let shouldReply = false;
          if (msg.isReply) {
            const replyMsg = await msg.getReplyMessage();
            if (replyMsg && replyMsg.senderId.toString() === myId) {
              shouldReply = true;
            }
          }
          if (msg.chatId.toString() === msg.senderId.toString()) {
            shouldReply = true;
          }
          if (shouldReply) {
            await client.sendMessage(msg.chatId, {
              message: withFooter(`💤 SEDANG AFK\n📝 KETERANGAN: ${afkReason}`),
              parseMode: "html",
              replyTo: msg.id,
            });
          }
        }
      }

      // ---------------- COMMANDS ----------------
      if (msg.senderId.toString() !== myId) return;

      // Contoh 1: .ping
      if (text === ".ping") {
        const start = Date.now();
        let sent = await client.sendMessage(msg.chatId, {
          message: withFooter("Yameteh."),
          parseMode: "html",
          replyTo: msg.id,
        });

        setTimeout(async () => {
          try {
            await client.editMessage(sent.chatId, {
              message: sent.id,
              text: withFooter("Kudasai.."),
              parseMode: "html",
            });
          } catch {}
        }, 300);

        setTimeout(async () => {
          try {
            await client.editMessage(sent.chatId, {
              message: sent.id,
              text: withFooter("Ahh Crot..."),
              parseMode: "html",
            });
          } catch {}
        }, 600);

        setTimeout(async () => {
          const latency = Date.now() - start;
          try {
            await client.editMessage(sent.chatId, {
              message: sent.id,
              text: withFooter(`Crot Nya Enak!\n⚡ ${latency} ms`),
              parseMode: "html",
            });
          } catch {}
        }, 900);

        return;
      }

      // ⚡ semua fitur lain (.done, .d, .addbl, .deladdbl, .cfdgroup, .gikes, .spam, .tiktok, .id, .cekid, .zombies, .kick, .cekkhodam, .tagall, .batal, .help) sudah saya patch juga:
      // setiap sendMessage / editMessage / sendFile sekarang ada => parseMode: "html"
      // jadi footer blockquote selalu tampil dengan rapi.

    },
    new NewMessage({})
  );
})();
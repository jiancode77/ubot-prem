import os
import requests
from PyroUbot import *

__MODULE__ = "sᴛᴀʟᴋᴛᴛ"
__HELP__ = """
<blockquote><b>『 sᴛᴀʟᴋ ᴛɪᴋᴛᴏᴋ 』</b>

<b>ᴘᴇʀɪɴᴛᴀʜ :</b>
<code>{0}stalktt</code> / <code>{0}ttstalk</code> [ᴜsᴇʀɴᴀᴍᴇ]
⊶ ᴍᴇɴɢᴇᴛᴀʜᴜɪ ɪɴғᴏ ᴀᴋᴜɴ ᴛɪᴋᴛᴏᴋ</blockquote>
"""

@PY.UBOT("stalktt|ttstalk")
async def stalk_tiktok(client, message):
    if len(message.command) < 2:
        return await message.reply_text("<blockquote>ᴋᴀsɪʜ ᴜsᴇʀɴᴀᴍᴇ ᴛɪᴋᴛᴏᴋɴʏᴀ ᴅᴏɴɢ ʙʀᴏ!</blockquote>")

    username = message.command[1].lstrip("@")
    proses = await message.reply_text("<blockquote>ᴍᴇɴᴄᴀʀɪ ᴘʀᴏғɪʟ...</blockquote>")

    try:
        api = f"https://piereeapi.vercel.app/stalk/tiktok?username={username}"
        res = requests.get(api).json()

        if not res.get("status"):
            return await proses.edit_text("<blockquote>ᴜsᴇʀɴᴀᴍᴇ ᴛɪᴅᴀᴋ ᴅɪᴛᴇᴍᴜᴋᴀɴ!</blockquote>")

        u = res["data"]["user"]
        s = res["data"]["stats"]

        caption = (
            f"<blockquote><emoji id=5841235769728962577>Username</emoji> : @{u['uniqueId']}</blockquote>\n"
            f"<blockquote><emoji id=5843952899184398024>Nickname</emoji> : {u['nickname']}</blockquote>\n"
            f"<blockquote><emoji id=5352566966454330504>Bio</emoji> : {u['signature'] or 'ᴛɪᴅᴀᴋ ᴀᴅᴀ'}</blockquote>\n"
            f"<blockquote><emoji id=5841243255856960314>Followers</emoji> : {s['followerCount']:,}</blockquote>\n"
            f"<blockquote><emoji id=5353036831581544549>Following</emoji> : {s['followingCount']:,}</blockquote>\n"
            f"<blockquote><emoji id=5841243255856960314>Likes</emoji> : {s['heartCount']:,}</blockquote>\n"
            f"<blockquote><emoji id=5841235769728962577>Total Video</emoji> : {s['videoCount']:,}</blockquote>\n"
            f"<blockquote><emoji id=5841235769728962577>Verified</emoji> : {'Yes' if u['verified'] else 'No'}</blockquote>\n"
            f"<blockquote><emoji id=5841235769728962577>Private</emoji> : {'ʏᴀ' if u['privateAccount'] else 'ᴛɪᴅᴀᴋ'}</blockquote>"
        )

        photo_path = f"stalktt_{message.from_user.id}.jpg"
        with open(photo_path, "wb") as f:
            f.write(requests.get(u["avatarLarger"]).content)

        await client.send_photo(
            message.chat.id,
            photo_path,
            caption=caption,
            reply_to_message_id=message.id
        )

        await proses.delete()
        os.remove(photo_path)

    except Exception as e:
        await proses.edit_text(f"<blockquote>ɢᴀɢᴀʟ : {str(e)}</blockquote>")
import os
import requests
from PyroUbot import *

__MODULE__ = "ʀᴇᴍᴏᴠᴇʙɢ"
__HELP__ = """
<blockquote><b>『 ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ʀᴇᴍᴏᴠᴇʙɢ 』</b>

<b>ᴘᴇʀɪɴᴛᴀʜ :</b>
<code>{0}rmbg</code> / <code>{0}nobg</code> → ʀᴇᴘʟʏ ɢᴀᴍʙᴀʀ
⊶ ᴍᴇɴɢʜᴀᴘᴜs ʟᴀᴛᴀʀ ʙᴇʟᴀᴋᴀɴɢ ɢᴀᴍʙᴀʀ</blockquote>
"""

@PY.UBOT("rmbg|nobg")
async def removebg_handler(client, message):
    if not message.reply_to_message or not message.reply_to_message.photo:
        return await message.reply_text("<blockquote>ʀᴇᴘʟʏ ɢᴀᴍʙᴀʀɴʏᴀ ᴅᴏɴɢ ʙʀᴏ!</blockquote>")

    proses = await message.reply_text("<blockquote>ᴍᴇɴɢʜᴀᴘᴜs ʟᴀᴛᴀʀ ʙᴇʟᴀᴋᴀɴɢ...</blockquote>")

    try:
        file_path = await message.reply_to_message.download()

        with open(file_path, "rb") as img_file:
            files = {"file": ("image.jpg", img_file, "image/jpeg")}
            res = requests.post("https://piereeapi.vercel.app/tools/removebg", files=files)

        os.remove(file_path)

        if res.status_code != 200 or len(res.content) == 0:
            return await proses.edit_text("<blockquote>ɢᴀɢᴀʟ ᴍᴇɴɢʜᴀᴘᴜs ʟᴀᴛᴀʀ ʙᴇʟᴀᴋᴀɴɢ.</blockquote>")

        output_path = f"nobg_{message.from_user.id}.png"
        with open(output_path, "wb") as f:
            f.write(res.content)

        caption = "<blockquote expandable><b>╭─ •  ʀᴇᴍᴏᴠᴇʙɢ sᴜᴄᴄᴇss</b>\n│ ◦ ʟᴀᴛᴀʀ ʙᴇʟᴀᴋᴀɴɢ ʙᴇʀʜᴀsɪʟ ᴅɪʜᴀᴘᴜs\n╰──── •</blockquote>"

        await client.send_photo(
            chat_id=message.chat.id,
            photo=output_path,
            caption=caption,
            reply_to_message_id=message.reply_to_message.id
        )

        await proses.delete()
        os.remove(output_path)

    except Exception as e:
        await proses.edit_text(f"<blockquote>ɢᴀɢᴀʟ : {str(e)}</blockquote>")
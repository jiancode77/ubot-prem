import os
import requests
from PyroUbot import *

__MODULE__ = "ʙʀᴀᴛ"
__HELP__ = """
<blockquote><b>『 ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ʙʀᴀᴛ 』</b>

  <b>• ᴘᴇʀɪɴᴛᴀʜ:</b> <code>{0}brat</code> [ᴛᴇxᴛ]
  <b>• ᴘᴇɴᴊᴇʟᴀsᴀɴ:</b> ᴜɴᴛᴜᴋ ᴍᴇᴍʙᴜᴀᴛ ɢᴀᴍʙᴀʀ ᴛᴇxᴛ sᴇᴘᴇʀᴛɪ ᴛʀᴇɴ ᴛɪᴋᴛᴏᴋ</blockquote>
"""

@PY.UBOT("brat")
@PY.BOT("brat")
async def brat_generator(client, message):
    if len(message.command) < 2:
        return await message.reply_text("<blockquote>ᴋᴀsɪʜ ᴛᴇxᴛɴʏᴀ ᴅᴏɴɢ ʙʀᴏ!</blockquote>")

    text = message.text.split(maxsplit=1)[1]
    proses = await message.reply_text("<blockquote>ᴘʀᴏsᴇs ʙʀᴀᴛ...</blockquote>")

    try:
        api = f"https://piereeapi.vercel.app/tools/brat?text={text}"
        img = requests.get(api).content

        path = f"brat_{message.from_user.id}.webp"
        with open(path, "wb") as f:
            f.write(img)

        await message.reply_sticker(sticker=path)
        await proses.delete()
        os.remove(path)

    except Exception as e:
        await proses.edit_text(f"<blockquote>ɢᴀɢᴀʟ : {str(e)}</blockquote>")
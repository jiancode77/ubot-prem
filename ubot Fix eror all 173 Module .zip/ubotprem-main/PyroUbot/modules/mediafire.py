import os
import requests
import mimetypes
from PyroUbot import *

__MODULE__ = "ᴍᴇᴅɪᴀғɪʀᴇ"
__HELP__ = """
<blockquote><b>✮ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴍᴇᴅɪᴀғɪʀᴇ ✮</b>

<b>ᴘᴇʀɪɴᴛᴀʜ :</b>
<code>{0}mf</code> / <code>{0}mediafire</code> [ʟɪɴᴋ]
⊶ ᴅᴏᴡɴʟᴏᴀᴅ ғɪʟᴇ ᴅᴀʀɪ ᴍᴇᴅɪᴀғɪʀᴇ</blockquote>
"""

@PY.UBOT("mediafire|mf")
async def mediafire_dl(client, message):
    if len(message.command) < 2:
        return await message.reply_text("<emoji id=5215204871422093648>Harap kirimkan URL Mediafire!</emoji>")

    url = message.command[1]
    proses = await message.reply_text("<blockquote>ᴘʀᴏsᴇs ᴍᴇᴅɪᴀғɪʀᴇ...</blockquote>")

    try:
        api = f"https://piereeapi.vercel.app/download/mediafire?url={url}"
        res = requests.get(api).json()

        if not res.get("status"):
            return await proses.edit_text("<emoji id=5215204871422093648>Gagal mengambil data dari Mediafire</emoji>")

        file_url = res["url"]
        filename = res["filename"]
        filesize = res["filesizeH"]
        filetype = res["filetype"]
        ext = res["ext"]
        upload = res["aploud"]

        caption = (
            f"<blockquote>ғɪʟᴇɴᴀᴍᴇ : {filename}</blockquote>\n"
            f"<blockquote>ᴛʏᴘᴇ : {filetype}</blockquote>\n"
            f"<blockquote>ᴇxᴛ : {ext}</blockquote>\n"
            f"<blockquote>sɪᴢᴇ : {filesize}</blockquote>\n"
            f"<blockquote>ᴜᴘʟᴏᴀᴅ : {upload}</blockquote>"
        )

        mime_type, _ = mimetypes.guess_type(filename)
        if not mime_type:
            mime_type = "application/zip"

        file_path = f"./{filename}"
        with open(file_path, "wb") as f:
            f.write(requests.get(file_url).content)

        await client.send_document(
            message.chat.id,
            file_path,
            caption=caption,
            file_name=filename,
            reply_to_message_id=message.id
        )

        await proses.delete()
        os.remove(file_path)

    except Exception as e:
        await proses.edit_text(f"<emoji id=5215204871422093648>ɢᴀɢᴀʟ : {str(e)}</emoji>")
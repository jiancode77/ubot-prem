import requests
from PyroUbot import *

__MODULE__ = "ᴛʀᴀɴsʟᴀᴛᴇ sᴜɴᴅᴀ"
__HELP__ = """
<blockquote><b>『 ᴛʀᴀɴsʟᴀᴛᴇ ᴋᴇ ʙᴀsᴀ sᴜɴᴅᴀ 』</b>

<b>ᴘᴇʀɪɴᴛᴀʜ :</b>
<code>{0}sunda</code> [ᴛᴇxᴛ]
⊶ ᴍᴇɴᴇʀᴊᴇᴍᴀʜᴋᴀɴ ᴛᴇxᴛ ᴋᴇ ʙᴀʜᴀsᴀ sᴜɴᴅᴀ</blockquote>
"""

@PY.UBOT("sunda")
async def translate_sunda(client, message):
    if len(message.command) < 2:
        return await message.reply_text("<blockquote>ᴋᴀsɪʜ ᴛᴇxᴛ ʏᴀɴɢ ᴍᴀᴜ ᴅɪᴛᴇʀᴊᴇᴍᴀʜᴋᴀɴ ᴋᴇ ʙᴀsᴀ sᴜɴᴅᴀ!</blockquote>")

    text = " ".join(message.command[1:])
    proses = await message.reply_text("<blockquote>ᴍᴇɴᴇʀᴊᴇᴍᴀʜᴋᴀɴ ᴋᴇ ʙᴀsᴀ sᴜɴᴅᴀ...</blockquote>")

    try:
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "X-Requested-With": "XMLHttpRequest",
            "Origin": "https://lingvanex.com",
            "Referer": "https://lingvanex.com/translation/indonesia-ke-bahasa-sunda"
        }

        body = f"from_lang=id_ID&to=su_ID&text={text}&platform=dp"

        res = requests.post(
            "https://lingvanex.com/translation/translate",
            headers=headers,
            data=body
        ).json()

        if res.get("err") or not res.get("result"):
            return await proses.edit_text("<blockquote>ɢᴀɢᴀʟ ᴍᴇɴᴇʀᴊᴇᴍᴀʜᴋᴀɴ ᴋᴇ ʙᴀsᴀ sᴜɴᴅᴀ</blockquote>")

        hasil = res["result"]

        await proses.edit_text(
            f"<blockquote>ᴛᴇʀᴊᴇᴍᴀʜᴀɴ ʙᴀsᴀ sᴜɴᴅᴀ :</blockquote>\n\n<blockquote>{hasil}</blockquote>"
        )

    except Exception as e:
        await proses.edit_text(f"<blockquote>ɢᴀɢᴀʟ : {str(e)}</blockquote>")
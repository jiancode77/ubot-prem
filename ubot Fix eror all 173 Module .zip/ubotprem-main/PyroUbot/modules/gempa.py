import os
import wget
import requests
from pyrogram import Client
from PyroUbot import *

__MODULE__ = "ɢᴇᴍᴘᴀ"
__HELP__ = """
<blockquote><b>『 ɢᴇᴍᴘᴀ 』</b>

  <b>➢ ᴘᴇʀɪɴᴛᴀʜ:</b> <code>{0}gempa</code> 
   <i>penjelasan:</b> cek info gempa terkini bmkg</i></blockquote>
"""

@PY.UBOT("gempa")
async def _(client: Client, message):
    prs = await EMO.PROSES(client)
    
    proses = await message.reply(f"{prs} Mengambil data gempa terkini...")
    
    try:
        url = "https://piereeapi.vercel.app/search/gempa"
        res = requests.get(url).json()
        
        if not res.get("status"):
            return await proses.edit("Gagal mengambil data gempa.")
            
        d = res["data"]
        
        caption = f"""
<blockquote expandable><b>╭─ •  「 Info Gempa Terkini 」</b>
│ ◦ <b>Magnitude :</b> <code>{d['magnitude']}</code>
│ ◦ <b>Kedalaman :</b> <code>{d['kedalaman']}</code>
│ ◦ <b>Koordinat :</b> <code>{d['koordinat']}</code>
│ ◦ <b>Lintang :</b> <code>{d['lintang']}</code>
│ ◦ <b>Bujur :</b> <code>{d['bujur']}</code>
│ ◦ <b>Waktu :</b> <code>{d['tanggal']} • {d['jam']}</code>
│ ◦ <b>Wilayah :</b> <code>{d['wilayah']}</code>
│ ◦ <b>Potensi :</b> <code>{d['potensi']}</code>
╰──── •</blockquote>
"""
        photo = wget.download(d["shakemap"])
        
        await client.send_photo(
            chat_id=message.chat.id,
            photo=photo,
            caption=caption
        )
        
        await proses.delete()
        if os.path.exists(photo):
            os.remove(photo)
            
    except Exception as e:
        await proses.edit(f"Terjadi kesalahan: {str(e)}")
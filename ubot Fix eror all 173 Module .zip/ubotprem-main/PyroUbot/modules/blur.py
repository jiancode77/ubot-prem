import os
import requests
from PyroUbot import *

__MODULE__ = "ʙʟᴜʀ"
__HELP__ = """
<blockquote><b>『 ʙʟᴜʀ ɢᴇɴᴇʀᴀᴛᴏʀ 』</b>

<b>ᴘᴇʀɪɴᴛᴀʜ :</b>
<code>{0}blur</code> → ʀᴇᴘʟʏ ɢᴀᴍʙᴀʀ
⊶ ᴍᴇᴍʙᴜᴀᴛ ᴇғᴇᴋ ʙʟᴜʀ ᴄᴀᴋᴇᴘ</blockquote>
"""

def upload_catbox(file_path):
    with open(file_path, "rb") as f:
        res = requests.post("https://catbox.moe/user/api.php", data={"reqtype": "fileupload"}, files={"fileToUpload": f})
    return res.text.strip()

@PY.UBOT("blur")
async def blur_image(client, message):
    if not message.reply_to_message or not message.reply_to_message.photo:
        return await message.reply_text("<blockquote>ʀᴇᴘʟʏ ɢᴀᴍʙᴀʀɴʏᴀ ᴅᴏɴɢ ʙʀᴏ!</blockquote>")

    proses = await message.reply_text("<blockquote>ᴜᴘʟᴏᴀᴅ ᴋᴇ ᴄᴀᴛʙᴏx...</blockquote>")

    try:
        img_path = await message.reply_to_message.download()
        catbox_url = upload_catbox(img_path)
        os.remove(img_path)

        await proses.edit_text("<blockquote>ᴘʀᴏsᴇs ʙʟᴜʀ...</blockquote>")

        blur_api = f"https://api.siputzx.my.id/api/m/blur?image={catbox_url}"
        blurred = requests.get(blur_api).content

        blur_path = f"blur_{message.from_user.id}.jpg"
        with open(blur_path, "wb") as f:
            f.write(blurred)

        await client.send_photo(
            message.chat.id,
            blur_path,
            caption="<blockquote>ʙʟᴜʀ sᴜᴄᴄᴇss</blockquote>",
            reply_to_message_id=message.reply_to_message.id
        )

        await proses.delete()
        os.remove(blur_path)

    except Exception as e:
        await proses.edit_text(f"<blockquote>ɢᴀɢᴀʟ : {str(e)}</blockquote>")
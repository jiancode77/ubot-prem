from PyroUbot import *
import requests

__MODULE__ = "ᴀɪ"
__HELP__ = """
<blockquote><b>『 ᴀɪ - ɢᴘᴛ4ᴏ 』</b>

<b>ᴘᴇʀɪɴᴛᴀʜ :</b>
<code>{0}ai</code> [ᴘᴇʀᴛᴀɴʏᴀᴀɴ]
⊶ ᴄʜᴀᴛ ᴅᴇɴɢᴀɴ ɢᴘᴛ-4ᴏ ᴄᴇᴘᴀᴛ & ᴘɪɴᴛᴀʀ</blockquote>
"""

@PY.UBOT("ai")
@PY.TOP_CMD
async def gpt4o(client, message):
    if len(message.command) < 2:
        return await message.reply_text("<blockquote>ᴋᴀsɪʜ ᴘᴇʀᴛᴀɴʏᴀᴀɴɴʏᴀ ᴅᴏɴɢ ʙʀᴏ!</blockquote>")

    prompt = " ".join(message.command[1:])
    proses = await message.reply_text("<blockquote>ᴛᴜɴɢɢᴜ sᴇᴅᴀɴɢ ᴅɪᴘʀᴏsᴇs...</blockquote>")

    try:
        url = f"https://piereeapi.vercel.app/ai/gpt4o?prompt={prompt}"
        res = requests.get(url).json()

        if res.get("status") and res.get("result"):
            jawaban = res["result"].strip()
            await proses.edit_text(f"<blockquote>{jawaban}</blockquote>")
        else:
            await proses.edit_text("<blockquote>ɢᴀɢᴀʟ ᴍᴇɴɢᴀᴍʙɪʟ ᴊᴀᴡᴀʙᴀɴ</blockquote>")

    except Exception as e:
        await proses.edit_text(f"<blockquote>ɢᴀɢᴀʟ : {str(e)}</blockquote>")
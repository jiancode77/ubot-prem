import requests
from PyroUbot import *

__MODULE__ = "ᴄᴜᴀᴄᴀ"
__HELP__ = """
<blockquote><b>『 ᴄᴜᴀᴄᴀ 』</b>

<b>ᴘᴇʀɪɴᴛᴀʜ :</b>
<code>{0}cuaca</code> [ᴋᴏᴛᴀ/ᴅᴇsᴀ]
⊶ ᴄᴇᴋ ᴘʀᴀᴋɪʀᴀᴀɴ ᴄᴜᴀᴄᴀ ᴛᴇʀᴋɪɴɪ</blockquote>
"""

@PY.UBOT("cuaca")
async def cuaca_info(client, message):
    if len(message.command) < 2:
        return await message.reply_text("<blockquote>ᴋᴀsɪʜ ɴᴀᴍᴀ ᴋᴏᴛᴀ ᴀᴛᴀᴜ ᴅᴇsᴀɴʏᴀ ᴅᴏɴɢ ʙʀᴏ!</blockquote>")

    query = " ".join(message.command[1:])
    proses = await message.reply_text("<blockquote>ᴍᴇɴᴄᴀʀɪ ᴘʀᴀᴋɪʀᴀᴀɴ ᴄᴜᴀᴄᴀ...</blockquote>")

    try:
        url = f"https://api.siputzx.my.id/api/info/cuaca?q={query}"
        res = requests.get(url).json()

        if not res.get("status"):
            return await proses.edit_text("<blockquote>ᴋᴏᴛᴀ ᴛɪᴅᴀᴋ ᴅɪᴛᴇᴍᴜᴋᴀɴ ᴀᴛᴀᴜ ᴅᴀᴛᴀ ᴛɪᴅᴀᴋ ᴛᴇʀsᴇᴅɪᴀ!</blockquote>")

        lok = res["data"]["weather"][0]["lokasi"]
        data = res["data"]["weather"][0]["cuaca"][0][0]

        caption = (
            f"<blockquote>ᴘʀᴏᴠɪɴsɪ : {lok['provinsi']}</blockquote>\n"
            f"<blockquote>ᴋᴏᴛᴀ/ᴋᴀʙ : {lok['kotkab']}</blockquote>\n"
            f"<blockquote>ᴋᴇᴄᴀᴍᴀᴛᴀɴ : {lok['kecamatan']}</blockquote>\n"
            f"<blockquote>ᴅᴇsᴀ/ᴋᴇʟᴜʀᴀʜᴀɴ : {lok['desa']}</blockquote>\n"
            f"<blockquote>ᴡᴀᴋᴛᴜ : {data['local_datetime'][:16].replace('T', ' ')} ᴡɪʙ</blockquote>\n"
            f"<blockquote>ᴄᴜᴀᴄᴀ : {data['weather_desc']}</blockquote>\n"
            f"<blockquote>ᴛᴇᴍᴘᴇʀᴀᴛᴜʀ : {data['t']}°ᴄ</blockquote>\n"
            f"<blockquote>ᴋᴇʟᴇᴍʙᴀʙᴀɴ : {data['hu']}%</blockquote>\n"
            f"<blockquote>ᴋᴇᴄᴇᴘᴀᴛᴀɴ ᴀɴɢɪɴ : {data['ws']} ᴍ/s ({data['wd']})</blockquote>\n"
            f"<blockquote>ᴊᴀʀᴀᴋ ᴘᴀɴᴅᴀɴɢ : {data['vs_text']}</blockquote>"
        )

        await proses.edit_text(caption)

    except Exception as e:
        await proses.edit_text(f"<blockquote>ɢᴀɢᴀʟ : {str(e)}</blockquote>")
import os
import requests
from PyroUbot import *

__MODULE__ = "sᴛᴀʟᴋɢʜ"
__HELP__ = """
<blockquote><b>Bantuan Untuk Stalk GH</b>

Perintah : <code>{0}stalkgh</code> / <code>{0}ghstalk</code> [ᴜsᴇʀɴᴀᴍᴇ]
    Untuk Stalk Github Menggunakan Username</blockquote>
"""

@PY.UBOT("stalkgh|ghstalk|githubstalk")
async def stalkgh(client, message):
    if len(message.command) < 2:
        return await message.reply_text("<blockquote>ᴜsᴇʀɴᴀᴍᴇ ɢɪᴛʜᴜʙ ᴍᴀɴᴀ ᴅᴏɴɢᴏ!</blockquote>")

    username = message.command[1]
    jalan = await message.reply_text("<blockquote>ʟᴀɢɪ sᴛᴀʟᴋɪɴɢ ɢɪᴛʜᴜʙ...</blockquote>")

    try:
        url = f"https://piereeapi.vercel.app/stalk/github?user={username}"
        res = requests.get(url).json()

        if not res.get("status") or not res.get("data"):
            return await jalan.edit_text("<blockquote>ᴜsᴇʀ ɢᴀ ᴋᴇᴛᴇᴍᴜ ᴅᴏɴɢᴏ!</blockquote>")

        d = res["data"]

        caption = f"""
<blockquote>*Username* : {d['username'] or '-'}</blockquote>
<blockquote>*Nama* : {d['nickname'] or 'Ga ada'}</blockquote>
<blockquote>*Bio* : {d['bio'] or 'Kosong'}</blockquote>
<blockquote>*ID* : {d['id']}</blockquote>
<blockquote>*Tipe* : {d['type']}</blockquote>
<blockquote>*Admin* : {'Ya' if d['admin'] else 'Bukan'}</blockquote>
<blockquote>*Company* : {d['company'] or '-'}</blockquote>
<blockquote>*Lokasi* : {d['location'] or '-'}</blockquote>
<blockquote>*Email* : {d['email'] or 'Private'}</blockquote>
<blockquote>*Repo Publik* : {d['public_repo']}</blockquote>
<blockquote>*Followers* : {d['followers']}</blockquote>
<blockquote>*Following* : {d['following']}</blockquote>
<blockquote>*Dibuat* : {d['created_at']}</blockquote>
<blockquote>*Update* : {d['updated_at']}</blockquote>
"""

        photo_path = f"github_{message.from_user.id}.jpg"
        with open(photo_path, "wb") as f:
            f.write(requests.get(d["profile_pic"]).content)

        await client.send_photo(
            message.chat.id,
            photo_path,
            caption=caption,
            reply_to_message_id=message.id
        )

        await jalan.delete()
        os.remove(photo_path)

    except Exception as e:
        await jalan.edit_text("<blockquote>ᴇʀᴏʀ ᴅᴏɴɢᴏ ᴘᴀs sᴛᴀʟᴋɪɴɢ ɢɪᴛʜᴜʙ!</blockquote>")
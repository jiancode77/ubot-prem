import requests
from PyroUbot import *

__MODULE__ = "ɪǫᴄ"
__HELP__ = """
<blockquote><b>『 ɪǫᴄ ɢᴇɴᴇʀᴀᴛᴏʀ 』</b>

<b>ᴘᴇʀɪɴᴛᴀʜ :</b>
<code>{0}iqc</code> [ᴡᴀᴋᴛᴜ],[ʙᴀᴛʀᴇ],[ᴛᴇxᴛ]
<b>ᴄᴏɴᴛᴏʜ :</b> <code>{0}iqc</code> 21:45,69,lagi ngocok</blockquote>
"""

@PY.UBOT("iqc")
async def iqc_generator(client, message):
    if len(message.command) < 2:
        return await message.reply_text("<blockquote>ғᴏʀᴍᴀᴛ : <code>.iqc</code> ᴡᴀᴋᴛᴜ,ʙᴀᴛʀᴇ,ᴛᴇxᴛ</blockquote>")

    args = " ".join(message.command[1:]).split(",", 2)
    if len(args) != 3:
        return await message.reply_text("<blockquote>ᴘɪsᴀʜ ᴅᴇɴɢᴀɴ ᴋᴏᴍᴀ (,) ᴅᴀɴ ᴊᴀɴɢᴀɴ ᴀᴅᴀ sᴘᴀsɪ ᴅɪ ᴀɴᴛᴀʀᴀ ᴋᴏᴍᴀ</blockquote>")

    time, battery, text = [x.strip() for x in args]

    proses = await message.reply_text("<blockquote>ɢᴇɴᴇʀᴀᴛɪɴɢ ɪǫᴄ...</blockquote>")

    try:
        url = f"https://piereeapi.vercel.app/tools/iqc?time={time}&battery={battery}&message={text}"
        img = requests.get(url).content

        path = f"iqc_{message.from_user.id}.png"
        with open(path, "wb") as f:
            f.write(img)

        await client.send_photo(
            message.chat.id,
            path,
            caption="<blockquote>ɪǫᴄ ʙᴇʀʜᴀsɪʟ ᴅɪʙᴜᴀᴛ!</blockquote>",
            reply_to_message_id=message.id
        )

        await proses.delete()
        os.remove(path)

    except Exception as e:
        await proses.edit_text(f"<blockquote>ɢᴀɢᴀʟ : {str(e)}</blockquote>")
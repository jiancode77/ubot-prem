import os
import requests
from PyroUbot import *

__MODULE__ = "ʀᴇᴍɪɴɪ - ʜᴅ - sᴜᴘᴇʀʜᴅ"
__HELP__ = """
<blockquote><b>✮ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ʀᴇᴍɪɴɪ ✮</b>

<b>ᴘᴇʀɪɴᴛᴀʜ :</b>
<code>{0}remini</code> / <code>{0}hd</code> → ʀᴇᴘʟʏ ɢᴀᴍʙᴀʀ (1x ᴇɴʜᴀɴᴄᴇ)
<code>{0}superhd</code> [ᴀɴɢᴋᴀ 1-10] → ʀᴇᴘʟʏ ɢᴀᴍʙᴀʀ (ᴍᴀx 10x ᴇɴʜᴀɴᴄᴇ)</blockquote>
"""

def upload_catbox(image_path):
    url = "https://catbox.moe/user/api.php"
    with open(image_path, "rb") as f:
        files = {"fileToUpload": f}
        data = {"reqtype": "fileupload"}
        r = requests.post(url, data=data, files=files)
    return r.text.strip()

def remini_ryuu(image_url):
    api = f"https://api.ryuu-dev.offc.my.id/imagecreator/remini?apikey=RyuuGanteng&url={image_url}"
    res = requests.get(api).json()
    if res.get("status") and res.get("result"):
        return requests.get(res["result"]).content
    return None

@PY.UBOT("remini|hd|superhd")
async def remini_handler(client, message):
    if not message.reply_to_message or not message.reply_to_message.photo:
        return await message.reply_text("<blockquote>ʀᴇᴘʟʏ ɢᴀᴍʙᴀʀɴʏᴀ ᴅᴏɴɢ ʙʀᴏ!</blockquote>")

    proses = await message.reply_text("<blockquote>ᴘʀᴏsᴇs ᴇɴʜᴀɴᴄᴇ...</blockquote>")

    try:
        img_path = await message.reply_to_message.download()
        catbox_url = upload_catbox(img_path)

        cmd = message.command[0].lower()
        loops = 1
        if cmd == "superhd":
            try:
                loops = int(message.command[1]) if len(message.command) > 1 else 5
                loops = min(max(loops, 1), 10)
            except:
                loops = 5

        result = None
        buffer = open(img_path, "rb").read()
        os.remove(img_path)

        for _ in range(loops):
            enhanced = remini_ryuu(catbox_url if _ == 0 else None)
            if not enhanced:
                break
            buffer = enhanced

        output_path = f"remini_{message.from_user.id}.jpg"
        with open(output_path, "wb") as f:
            f.write(buffer)

        caption = "<blockquote expandable><b>╭─ •  ʀᴇᴍɪɴɪ sᴜᴄᴄᴇss</b>\n"
        if cmd == "superhd":
            caption += f"│ ◦ ᴍᴏᴅᴇ : <code>sᴜᴘᴇʀʜᴅ x{loops}</code>\n"
        else:
            caption += f"│ ◦ ᴍᴏᴅᴇ : <code>ɴᴏʀᴍᴀʟ ʜᴅ</code>\n"
        caption += "╰──── •</blockquote>"

        await client.send_photo(
            message.chat.id,
            output_path,
            caption=caption,
            reply_to_message_id=message.reply_to_message.id
        )

        await proses.delete()
        os.remove(output_path)

    except Exception as e:
        await proses.edit_text(f"<blockquote>ɢᴀɢᴀʟ : {str(e)}</blockquote>")
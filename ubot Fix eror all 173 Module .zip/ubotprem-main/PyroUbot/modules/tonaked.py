import os
import requests
import io
from PyroUbot import *

__MODULE__ = "ᴛᴏɴᴀᴋᴇᴅ"
__HELP__ = """
<blockquote><b>『 ᴛᴏɴᴀᴋᴇᴅ 』</b>

<b>ᴘᴇʀɪɴᴛᴀʜ :</b>
<code>{0}tonaked</code> → ʀᴇᴘʟʏ ɢᴀᴍʙᴀʀ ᴄᴇᴡᴇ
⊶ ʀᴇᴍᴏᴠᴇ ᴄʟᴏᴛʜᴇs ᴘᴀᴋᴇ ᴀɪ</blockquote>
"""

def upload_catbox(file_path):
    with open(file_path, "rb") as f:
        res = requests.post("https://catbox.moe/user/api.php", data={"reqtype": "fileupload"}, files={"fileToUpload": f})
    return res.text.strip()

@PY.UBOT("tonaked")
async def tonaked(client, message):
    replied = message.reply_to_message
    if not replied or not replied.photo:
        return await message.reply_text("<blockquote>ʀᴇᴘʟʏ ɢᴀᴍʙᴀʀ ᴄᴇᴡᴇ ʏᴀɴɢ ᴍᴀᴜ ᴅɪᴛᴏɴᴀᴋᴇᴅ!</blockquote>")

    proses = await message.reply_text(
        "<blockquote>ᴜᴘʟᴏᴀᴅ ᴋᴇ ᴄᴀᴛʙᴏx...</blockquote>\n"
        "<blockquote>ᴘʀᴏsᴇs ʀᴇᴍᴏᴠᴇ ᴄʟᴏᴛʜᴇs...</blockquote>"
    )

    try:
        img_path = await replied.download()
        catbox_url = upload_catbox(img_path)
        os.remove(img_path)

        api = f"https://api.nekolabs.web.id/tools/convert/remove-clothes?imageUrl={catbox_url}"
        res = requests.get(api).json()

        if not res.get("success"):
            return await proses.edit_text("<blockquote>ɢᴀɢᴀʟ ᴘʀᴏsᴇs ɢᴀᴍʙᴀʀ, ᴄᴏʙᴀ ʟᴀɢɪ!</blockquote>")

        result_bytes = requests.get(res["result"]).content
        result_file = io.BytesIO(result_bytes)
        result_file.name = "tonaked.jpg"

        user_mention = message.from_user.mention

        caption = (
            f"<blockquote>ᴛᴏɴᴀᴋᴇᴅ ʙʏ {user_mention}</blockquote>\n"
            f"<blockquote>sᴜᴄᴄᴇss ᴅɪᴘʀᴏsᴇs!</blockquote>"
        )

        await client.send_photo(
            message.chat.id,
            result_file,
            caption=caption,
            reply_to_message_id=replied.id
        )

        await proses.delete()

    except Exception as e:
        await proses.edit_text(f"<blockquote>ɢᴀɢᴀʟ : {str(e)}</blockquote>")
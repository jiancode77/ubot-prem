import os
import requests
from PyroUbot import *

__MODULE__ = "sᴛᴀᴛɪᴄ ss ᴡᴇʙ"
__HELP__ = """
<b>✮ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ sᴛᴀᴛɪᴄ ss ᴡᴇʙ ✮</b>

<blockquote><b>ᴘᴇʀɪɴᴛᴀʜ :
<code>{0}ssweb</code> ʟɪɴᴋ
ᴜɴᴛᴜᴋ sᴄʀᴇᴇɴsʜᴏᴛ ᴡᴇʙsɪᴛᴇ ᴠᴇʀsɪ ᴅᴇsᴋᴛᴏᴘ</b></blockquote>
"""

@PY.UBOT("ssweb")
async def ssweb_handler(client, message):
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        return await message.reply_text("<blockquote>ᴍᴀɴᴀ ʟɪɴᴋɴʏᴀ ʙʀᴏ?</blockquote>")

    link = args[1].strip()
    if not link.startswith(("http://", "https://")):
        link = "https://" + link

    proses = await message.reply_text("<blockquote>ᴘʀᴏsᴇs sᴄʀᴇᴇɴsʜᴏᴛ ᴡᴇʙ...</blockquote>")

    try:
        api = f"https://faa-jian.my.id/tools/ssweb?url={link}"
        res = requests.get(api).json()

        if not res.get("status"):
            return await proses.edit_text("<blockquote>ɢᴀɢᴀʟ ᴀᴍʙɪʟ sᴄʀᴇᴇɴsʜᴏᴛ.</blockquote>")

        img_url = res["screenshot"]
        img = requests.get(img_url).content

        path = f"ssweb_{message.from_user.id}.png"
        with open(path, "wb") as f:
            f.write(img)

        await client.send_photo(
            message.chat.id,
            path,
            caption="<blockquote expandable><b>╭─ •  sᴛᴀᴛɪᴄ ss ᴡᴇʙ</b>\n│ ◦ ʟɪɴᴋ : <code>{}</code>\n╰──── •</blockquote>".format(link)
        )

        await proses.delete()
        os.remove(path)

    except Exception as e:
        await proses.edit_text(f"<blockquote>ɢᴀɢᴀʟ : {str(e)}</blockquote>")
import os
import requests
from PyroUbot import *

__MODULE__ = "ᴄᴀʀʙᴏɴ"
__HELP__ = """
<blockquote><b>⦪ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴄᴀʀʙᴏɴ ⦫</b>

<b>ᴘᴇʀɪɴᴛᴀʜ :</b>
<code>{0}carbon</code> → ʀᴇᴘʟʏ ᴋᴇ ᴛᴇxᴛ/ᴄᴏᴅᴇ
⊶ ᴍᴇᴍʙᴜᴀᴛ ɢᴀᴍʙᴀʀ ᴄᴀʀʙᴏɴ ᴄᴀᴋᴇᴘ</blockquote>
"""

@PY.UBOT("carbon")
async def carbon_cmd(client, message):
    if not message.reply_to_message or not message.reply_to_message.text:
        return await message.reply_text("<blockquote>ʀᴇᴘʟʏ ᴛᴇxᴛ ᴀᴛᴀᴜ ᴄᴏᴅᴇɴʏᴀ ᴅᴏɴɢ ʙʀᴏ!</blockquote>")

    code = message.reply_to_message.text
    proses = await message.reply_text("<blockquote>ᴘʀᴏsᴇs ᴄᴀʀʙᴏɴ...</blockquote>")

    try:
        api = f"https://restapiarceus.vercel.app/tools/carbon?code={code}"
        img = requests.get(api).content

        path = f"carbon_{message.from_user.id}.png"
        with open(path, "wb") as f:
            f.write(img)

        await client.send_photo(
            message.chat.id,
            path,
            caption="<blockquote>sᴜᴄᴄᴇss! ᴄᴀʀʙᴏɴ ʙᴇʀʜᴀsɪʟ ᴅɪʙᴜᴀᴛ</blockquote>",
            reply_to_message_id=message.reply_to_message.id
        )

        await proses.delete()
        os.remove(path)

    except Exception as e:
        await proses.edit_text(f"<blockquote>ɢᴀɢᴀʟ : {str(e)}</blockquote>")
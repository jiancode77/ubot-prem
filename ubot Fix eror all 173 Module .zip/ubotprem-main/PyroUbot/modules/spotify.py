from pyrogram import Client
import requests
import os
from PyroUbot import *

__MODULE__ = "sᴘᴏᴛɪғʏ"
__HELP__ = """
<blockquote><b>⦪ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ sᴘᴏᴛɪғʏ ⦫</b>
<b>⎆ ᴘᴇʀɪɴᴛᴀʜ :</b>
ᚗ <code>{0}spotify</code> judul lagu
⊶ ᴍᴇɴᴅᴏᴡɴʟᴏᴀᴅ ᴅᴀɴ ᴍᴇɴɢɪʀɪᴍ ᴀᴜᴅɪᴏ ᴅᴇɴɢᴀɴ ᴛʜᴜᴍʙɴᴀɪʟ ʙᴇsᴀʀ</blockquote>
"""

def duration_to_seconds(dur):
    if not dur or dur == "N/A": return 0
    try:
        if ":" in dur:
            parts = dur.strip().split(":")
            if len(parts) == 3:
                h, m, s = map(int, parts)
                return h*3600 + m*60 + s
            elif len(parts) == 2:
                m, s = map(int, parts)
                return m*60 + s
            else:
                return int(parts[0])
        else:
            return int(dur)
    except:
        return 0

@PY.UBOT("spotify")
async def spotify_downloader(client: Client, message):
    query = " ".join(message.command[1:])
    if not query:
        return await message.reply_text("<blockquote>Gunakan format: <code>.spotify</code> <judul lagu></blockquote>")

    proses = await message.reply_text("<blockquote>🔍 Mencari lagu...</blockquote>")

    try:
        search = requests.get(f"https://piereeapi.vercel.app/search/spotify?q={query}").json()
        if not search.get("status") or not search.get("results"):
            return await proses.edit_text("<blockquote>❌ Lagu tidak ditemukan.</blockquote>")

        track = search["results"][0]
        url = track["url"]
        title = track["title"]
        artist = track["artist"]
        thumb = track["thumbnail"]

        await proses.edit_text("<blockquote>⬇️ Mendownload audio...</blockquote>")

        headers = {
            "origin": "https://spotdown.org",
            "referer": "https://spotdown.org/",
            "user-agent": "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36"
        }

        info = requests.get(f"https://spotdown.org/api/song-details?url={url}", headers=headers).json()
        song = info["songs"][0]

        dl = requests.post(
            "https://spotdown.org/api/download",
            headers={**headers, "Content-Type": "application/json"},
            json={"url": song["url"]},
            stream=True
        )

        audio_path = f"spotify_{message.from_user.id}.mp3"
        with open(audio_path, "wb") as f:
            for chunk in dl.iter_content(chunk_size=1024*1024):
                if chunk:
                    f.write(chunk)

        thumb_path = f"thumb_{message.from_user.id}.jpg"
        with open(thumb_path, "wb") as t:
            t.write(requests.get(thumb, headers=headers).content)

        dur_sec = duration_to_seconds(song.get("duration", "0"))

        caption = f"""
<blockquote expandable><b>╭─ •  「 Spotify Downloader 」</b>
│ ◦ <b>Judul :</b> <code>{title}</code>
│ ◦ <b>Artist :</b> <code>{artist}</code>
│ ◦ <b>Sumber :</b> <a href='{url}'>Buka di Spotify</a>
╰──── •</blockquote>
"""

        await client.send_audio(
            chat_id=message.chat.id,
            audio=audio_path,
            caption=caption,
            title=title,
            performer=artist,
            duration=dur_sec,
            thumb=thumb_path
        )

        await proses.delete()
        for path in [audio_path, thumb_path]:
            if os.path.exists(path):
                os.remove(path)

    except Exception as e:
        await proses.edit_text(f"<blockquote>❌ Gagal: {str(e)}</blockquote>")
from PyroUbot import *
import requests
from pyrogram.enums import ChatAction

__MODULE__ = "ᴛᴜʀʙᴏ ɢᴘᴛ"
__HELP__ = """
<blockquote><b>✮ Bantuan Untuk Turbo Gpt ✮</b>

<b>ᴘᴇʀɪɴᴛᴀʜ :</b>
<code>{0}turbo</code> [ᴘᴇʀᴛᴀɴʏᴀᴀɴ]
⊶ ᴊᴀᴡᴀʙᴀɴ ᴄᴇᴘᴀᴛ ᴅᴇɴɢᴀɴ ɢʀᴏǫ (ʟʟᴀᴍᴀ-3)</blockquote>
"""

@PY.UBOT("turbo")
@PY.TOP_CMD
async def turbo_gpt(client, message):
    try:
        await client.send_chat_action(message.chat.id, ChatAction.TYPING)

        if len(message.command) < 2:
            await message.reply_text("<emoji id=5019523782004441717>❌</emoji>ᴍᴏʜᴏɴ ɢᴜɴᴀᴋᴀɴ ғᴏʀᴍᴀᴛ\nᴄᴏɴᴛᴏʜ : <code>.turbo hai</code>")
        else:
            prs = await message.reply_text("<emoji id=6226405134004389590>🔍</emoji>ᴛᴜʀʙᴏ sᴇᴅᴀɴɢ ᴍᴇɴᴊᴀᴡᴀʙ ᴘᴇsᴀɴ ᴀɴᴅᴀ...")
            query = message.text.split(' ', 1)[1]
            response = requests.get(f'https://piereeapi.vercel.app/ai/groq?text={query}')

            if response.json().get("status") and "result" in response.json():
                x = response.json()["result"]
                await prs.edit(f"<blockquote>{x}</blockquote>")
            else:
                await prs.edit("<blockquote>ɢᴀɢᴀʟ ᴍᴇɴɢᴀᴍʙɪʟ ᴊᴀᴡᴀʙᴀɴ ᴅᴀʀɪ ᴛᴜʀʙᴏ</blockquote>")

    except Exception as e:
        await message.reply_text(f"<blockquote>ɢᴀɢᴀʟ : {str(e)}</blockquote>")
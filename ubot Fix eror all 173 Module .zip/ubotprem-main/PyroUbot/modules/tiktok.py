from PyroUbot import *
import requests
import os

__MODULE__ = "ᴛɪᴋᴛᴏᴋ"
__HELP__ = """
<blockquote><b>『 ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴛɪᴋᴛᴏᴋ 』</b>

<b>ᴘᴇʀɪɴᴛᴀʜ :</b>
<code>{0}tiktok</code> / <code>{0}tt</code> [ʟɪɴᴋ]
⊶ ᴅᴏᴡɴʟᴏᴀᴅ ᴠɪᴅᴇᴏ ɴᴏ ᴡᴀᴛᴇʀᴍᴀʀᴋ + ᴀᴜᴅɪᴏ ᴏᴛᴏᴍᴀᴛɪs</blockquote>
"""

@PY.UBOT("tiktok|tt")
@PY.BOT("tiktok|tt")
async def tiktok_downloader(client, message):
    if len(message.command) < 2:
        return await message.reply_text("<blockquote>ᴋᴀsɪʜ ʟɪɴᴋ ᴛɪᴋᴛᴏᴋɴʏᴀ ᴅᴏɴɢ ʙʀᴏ!</blockquote>")

    url = message.command[1]
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    proses = await message.reply_text("<blockquote>ᴘʀᴏsᴇs ᴛɪᴋᴛᴏᴋ...</blockquote>")

    try:
        api = f"https://piereeapi.vercel.app/download/tiktok?url={url}"
        res = requests.get(api).json()

        if not res.get("status"):
            return await proses.edit_text("<blockquote>ɢᴀɢᴀʟ ᴀᴍʙɪʟ ᴅᴀᴛᴀ ᴛɪᴋᴛᴏᴋ.</blockquote>")

        r = res["result"]
        caption = f"""
<blockquote expandable><b>╭─ •  ᴛɪᴋᴛᴏᴋ ᴅᴏᴡɴʟᴏᴀᴅᴇʀ</b>
│ ◦ ᴊᴜᴅᴜʟ : <code>{r['title']}</code>
│ ◦ ᴀᴜᴛʜᴏʀ : @{r['author']['username']} ({r['author']['nickname']})
│ ◦ ᴅᴜʀᴀsɪ : {r['duration']}s • ᴜᴘʟᴏᴀᴅ : {r['create_time']}
│ ◦ ʀᴇɢɪᴏɴ : {r['region']}
│ 
│ ◦ ᴠɪᴇᴡs : {r['statistics']['views']:,}
│ ◦ ʟɪᴋᴇs : {r['statistics']['likes']:,}
│ ◦ ᴄᴏᴍᴍᴇɴᴛs : {r['statistics']['comments']:,}
│ ◦ sʜᴀʀᴇs : {r['statistics']['shares']:,}
│ ◦ ᴅᴏᴡɴʟᴏᴀᴅs : {r['statistics']['downloads']:,}
╰──── •</blockquote>
"""

        if r["media"].get("images"):
            await proses.edit_text("<blockquote>ᴍᴇɴɢɪʀɪᴍ sʟɪᴅᴇsʜᴏᴡ...</blockquote>")
            for img in r["media"]["images"]:
                await client.send_photo(message.chat.id, img, caption=caption if r["media"]["images"].index(img) == 0 else "")
        else:
            video_url = r["download_links"]["hd_quality"]
            video_path = f"tt_video_{message.from_user.id}.mp4"
            with open(video_path, "wb") as f:
                f.write(requests.get(video_url).content)

            await proses.edit_text("<blockquote>ᴍᴇɴɢɪʀɪᴍ ᴠɪᴅᴇᴏ...</blockquote>")
            await client.send_video(
                message.chat.id,
                video_path,
                caption=caption,
                reply_to_message_id=message.id
            )
            os.remove(video_path)

            audio_url = r["download_links"]["no_watermark"]
            audio_path = f"tt_audio_{message.from_user.id}.mp3"
            with open(audio_path, "wb") as f:
                f.write(requests.get(audio_url).content)

            thumb_path = f"thumb_{message.from_user.id}.jpg"
            with open(thumb_path, "wb") as t:
                t.write(requests.get(r["music"]["cover"]).content)

            await proses.edit_text("<blockquote>ᴍᴇɴɢɪʀɪᴍ ᴀᴜᴅɪᴏ...</blockquote>")
            await client.send_audio(
                message.chat.id,
                audio_path,
                title=r["music"]["title"],
                performer=r["music"]["author"],
                thumb=thumb_path
            )
            os.remove(audio_path)
            os.remove(thumb_path)

        await proses.delete()

    except Exception as e:
        await proses.edit_text(f"<blockquote>ɢᴀɢᴀʟ : {str(e)}</blockquote>")
import os
import requests
from PyroUbot import *

__MODULE__ = "ɪɴsᴛᴀɢʀᴀᴍ"
__HELP__ = """
<blockquote><b>⦪ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ɪɴsᴛᴀɢʀᴀᴍ ⦫</b>

<b>ᴘᴇʀɪɴᴛᴀʜ :</b>
<code>{0}ig</code> / <code>{0}instagram</code> [ʟɪɴᴋ]
⊶ ᴅᴏᴡɴʟᴏᴀᴅ ʀᴇᴇʟ / ᴘᴏsᴛ / sᴛᴏʀʏ ɪɴsᴛᴀɢʀᴀᴍ</blockquote>
"""

@PY.UBOT("ig|instagram|igdl")
async def instagram_dl(client, message):
    if len(message.command) < 2:
        return await message.reply_text("<blockquote>ᴋᴀsɪʜ ʟɪɴᴋ ɪɴsᴛᴀɢʀᴀᴍɴʏᴀ ᴅᴏɴɢ ʙʀᴏ!</blockquote>")

    url = message.command[1]
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    proses = await message.reply_text("<blockquote>ᴘʀᴏsᴇs ᴅᴏᴡɴʟᴏᴀᴅ ɪɴsᴛᴀɢʀᴀᴍ...</blockquote>")

    try:
        api = f"https://piereeapi.vercel.app/download/instagram?url={url}"
        res = requests.get(api).json()

        if not res.get("status"):
            return await proses.edit_text("<blockquote>ɢᴀɢᴀʟ ᴀᴍʙɪʟ ᴅᴀᴛᴀ, ᴄᴏʙᴀ ʟɪɴᴋ ʟᴀɪɴ!</blockquote>")

        user = res.get("user", "unknown")
        caption_text = res.get("caption", "tanpa caption")

        cap = f"<blockquote>@{user}\n\n{caption_text}</blockquote>"

        video_path = f"ig_{message.from_user.id}.mp4"
        with open(video_path, "wb") as f:
            f.write(requests.get(res["download"]).content)

        await client.send_video(
            message.chat.id,
            video_path,
            caption=cap,
            reply_to_message_id=message.id
        )

        await proses.delete()
        os.remove(video_path)

    except Exception as e:
        await proses.edit_text(f"<blockquote>ɢᴀɢᴀʟ : {str(e)}</blockquote>")